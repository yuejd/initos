#!/usr/bin/env python
# -*- coding:utf-8 -*-
#
#   Author  :   Jiadi Yue
#   E-mail  :   jiadi.yue@emc.com
#   Date    :   15/04/16 06:57:19
#   Desc    :   find server node in switch online
#

import nwc_lib

def server_node_find(ser_ip, ser_username, ser_password, dev_type, switches):
    if dev_type == "linux":
        get_wwn = nwc_lib.get_linux_wwn
    elif dev_type == "solaris":
        get_wwn = nwc_lib.get_solaris_wwn
    elif dev_type == "vmware":
        get_wwn = nwc_lib.get_vmware_wwn
    elif dev_type == "hpux":
        get_wwn = nwc_lib.get_hpux_wwn
    elif dev_type == "aix":
        get_wwn = nwc_lib.get_aix_wwn
    else return

