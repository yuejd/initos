#!/usr/bin/env python
# -*- coding:utf-8 -*-
#
#   Author  :   Jiadi Yue
#   E-mail  :   jiadi.yue@emc.com
#   Date    :   15/01/26 14:54:30
#   Desc    :   for testing
#


from dbm import * 

#insert_server("10.108.102.251", "lxh8ser4", "root", "#1Danger0us", "solaris")
#update_server_credential("10.108.106.63", "lxh8ser4", "root", "#1Danger0us", "linux", "jiadi", "test")
#rescan_server_dev("10.108.105.67")

#host_info = open("ls_host_info", "r")
#for info in host_info:
#    ipaddr, username, password, devtype, hostname = info.strip().split()
#    print "%s: insert server %s\n" % (ipaddr, hostname)
#    insert_server(ipaddr, hostname, username, password, devtype)
